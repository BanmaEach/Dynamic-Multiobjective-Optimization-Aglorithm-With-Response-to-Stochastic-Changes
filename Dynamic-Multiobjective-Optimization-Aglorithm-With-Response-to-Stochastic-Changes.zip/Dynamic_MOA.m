function [rep,pop]=Dynamic_MOA(rep,pop,NN1,NN2,NN3,NN4,NN5,In,LastIn,InDim,RuleNum,OP_NOx,OP_ST,OP_CE,OP_SO2,OP_HCL,VarMin,VarMax)

%% 
e_NOx=OP_NOx(1)-OP_NOx(2);
e_ST=OP_ST(1)-OP_ST(2);
e_CE=OP_CE(1)-OP_CE(2);
e_SO2=OP_SO2(1)-OP_SO2(2);
e_HCL=OP_HCL(1)-OP_HCL(2);

SamIn=In;

a_NOx=NN1.a;
a0_NOx=NN1.a0;
Center_NOx=NN1.Center;
Width_NOx=NN1.Width;


for i=1:InDim
    for j=1:RuleNum
        MemFunUnitOut_NOx(i,j)=exp(-(SamIn(i)-Center_NOx(i,j))^2/Width_NOx(i,j)^2);% 隶属层输�?
    end
end
% 规则�?
RuleUnitOut_NOx=prod(MemFunUnitOut_NOx); %规则层输�?
% 归一化层
RuleUnitOutSum_NOx=sum(RuleUnitOut_NOx); %规则层输出求�?
NormValue_NOx=RuleUnitOut_NOx./RuleUnitOutSum_NOx; %归一化层输出
% 输出�?
W_NOx=a0_NOx+a_NOx'*SamIn;%规则后件输出
NetOut_NOx=NormValue_NOx*W_NOx; %单个样本输出层输出，即网络实际输�?

for i=1:InDim
    for j=1:RuleNum
        J_NOx_b(i,j)=-2*((W_NOx(j)-NetOut_NOx)/RuleUnitOutSum_NOx)*RuleUnitOut_NOx(j)*(SamIn(i)-Center_NOx(i,j))/(Width_NOx(i,j)^2);
    end
end

J_NOx=-(NormValue_NOx*a_NOx')-sum(J_NOx_b,2)';

H_NOx=J_NOx'*J_NOx;

g_NOx=J_NOx*e_NOx;


a_ST=NN2.a;
a0_ST=NN2.a0;
Center_ST=NN2.Center;
Width_ST=NN2.Width;

for i=1:InDim
    for j=1:RuleNum
        MemFunUnitOut_ST(i,j)=exp(-(SamIn(i)-Center_ST(i,j))^2/Width_ST(i,j)^2);% 隶属层输�?
    end
end
% 规则�?
RuleUnitOut_ST=prod(MemFunUnitOut_ST); %规则层输�?
% 归一化层
RuleUnitOutSum_ST=sum(RuleUnitOut_ST); %规则层输出求�?
NormValue_ST=RuleUnitOut_ST./RuleUnitOutSum_ST; %归一化层输出
% 输出�?
W_ST=a0_ST+a_ST'*SamIn;%规则后件输出
NetOut_ST=NormValue_ST*W_ST; %单个样本输出层输出，即网络实际输�?

for i=1:InDim
    for j=1:RuleNum
        J_ST_b(i,j)=-2*((W_ST(j)-NetOut_ST)/RuleUnitOutSum_ST)*RuleUnitOut_ST(j)*(SamIn(i)-Center_ST(i,j))/(Width_ST(i,j)^2);
    end
end

J_ST=-(NormValue_ST*a_ST')-sum(J_ST_b,2)';

H_ST=J_ST'*J_ST;

g_ST=J_ST*e_ST;



a_CE=NN3.a;
a0_CE=NN3.a0;
Center_CE=NN3.Center;
Width_CE=NN3.Width;

for i=1:InDim
    for j=1:RuleNum
        MemFunUnitOut_CE(i,j)=exp(-(SamIn(i)-Center_CE(i,j))^2/Width_CE(i,j)^2);% 隶属层输�?
    end
end
% 规则�?
RuleUnitOut_CE=prod(MemFunUnitOut_CE); %规则层输�?
% 归一化层
RuleUnitOutSum_CE=sum(RuleUnitOut_CE); %规则层输出求�?
NormValue_CE=RuleUnitOut_CE./RuleUnitOutSum_CE; %归一化层输出
% 输出�?
W_CE=a0_CE+a_CE'*SamIn;%规则后件输出
NetOut_CE=NormValue_CE*W_CE; %单个样本输出层输出，即网络实际输�?

for i=1:InDim
    for j=1:RuleNum
        J_CE_b(i,j)=-2*((W_CE(j)-NetOut_CE)/RuleUnitOutSum_CE)*RuleUnitOut_CE(j)*(SamIn(i)-Center_CE(i,j))/(Width_CE(i,j)^2);
    end
end

J_CE=-(NormValue_CE*a_CE')-sum(J_CE_b,2)';

H_CE=J_CE'*J_CE;

g_CE=J_CE*e_CE;




a_SO2=NN4.a;
a0_SO2=NN4.a0;
Center_SO2=NN4.Center;
Width_SO2=NN4.Width;

for i=1:InDim
    for j=1:RuleNum
        MemFunUnitOut_SO2(i,j)=exp(-(SamIn(i)-Center_SO2(i,j))^2/Width_SO2(i,j)^2);% 隶属层输�?
    end
end
% 规则�?
RuleUnitOut_SO2=prod(MemFunUnitOut_SO2); %规则层输�?
% 归一化层
RuleUnitOutSum_SO2=sum(RuleUnitOut_SO2); %规则层输出求�?
NormValue_SO2=RuleUnitOut_SO2./RuleUnitOutSum_SO2; %归一化层输出
% 输出�?
W_SO2=a0_SO2+a_SO2'*SamIn;%规则后件输出
NetOut_SO2=NormValue_SO2*W_SO2; %单个样本输出层输出，即网络实际输�?

for i=1:InDim
    for j=1:RuleNum
        J_SO2_b(i,j)=-2*((W_SO2(j)-NetOut_SO2)/RuleUnitOutSum_SO2)*RuleUnitOut_SO2(j)*(SamIn(i)-Center_SO2(i,j))/(Width_SO2(i,j)^2);
    end
end

J_SO2=-(NormValue_SO2*a_SO2')-sum(J_SO2_b,2)';

H_SO2=J_SO2'*J_SO2;

g_SO2=J_SO2*e_SO2;





a_HCL=NN5.a;
a0_HCL=NN5.a0;
Center_HCL=NN5.Center;
Width_HCL=NN5.Width;

for i=1:InDim
    for j=1:RuleNum
        MemFunUnitOut_HCL(i,j)=exp(-(SamIn(i)-Center_HCL(i,j))^2/Width_HCL(i,j)^2);% 隶属层输�?
    end
end
% 规则�?
RuleUnitOut_HCL=prod(MemFunUnitOut_HCL); %规则层输�?
% 归一化层
RuleUnitOutSum_HCL=sum(RuleUnitOut_HCL); %规则层输出求�?
NormValue_HCL=RuleUnitOut_HCL./RuleUnitOutSum_HCL; %归一化层输出
% 输出�?
W_HCL=a0_HCL+a_HCL'*SamIn;%规则后件输出
NetOut_HCL=NormValue_HCL*W_HCL; %单个样本输出层输出，即网络实际输�?

for i=1:InDim
    for j=1:RuleNum
        J_HCL_b(i,j)=-2*((W_HCL(j)-NetOut_HCL)/RuleUnitOutSum_HCL)*RuleUnitOut_HCL(j)*(SamIn(i)-Center_HCL(i,j))/(Width_HCL(i,j)^2);
    end
end

J_HCL=-(NormValue_HCL*a_HCL')-sum(J_HCL_b,2)';

H_HCL=J_HCL'*J_HCL;

g_HCL=J_HCL*e_HCL;

%% 
H_NOW=H_NOx+H_ST+H_CE+H_SO2+H_HCL;

lamda=0.1;

% lamda=mean(In./LastIn);

G=g_NOx+g_ST+g_CE+g_SO2+g_HCL;

Q_LM=H_NOW+(eye(InDim,InDim));

Delta=inv(Q_LM)*G';

X=In-LastIn;

Eta=X./Delta;



% eta=diag(-G'*(X.^(-1))'-H_NOW);


% LastIn+Eta.*Delta

DataIn_rep=zeros(InDim,numel(rep));
for t=1:numel(rep)
    rep(t).Pos(1)=rep(t).Pos(1)-Eta(1)*Delta(1);
    rep(t).Pos(2)=rep(t).Pos(2)-Eta(6)*Delta(6);
    rep(t).Pos = max(rep(t).Pos, VarMin);
    rep(t).Pos = min(rep(t).Pos, VarMax);
    DataIn_rep(:,t)=[rep(t).Pos(1);In(2:5,:);rep(t).Pos(2)];
    Cost1=CostFunction(NN1,DataIn_rep(:,t),RuleNum,InDim);
    Cost4=CostFunction(NN1,DataIn_rep(:,t),RuleNum,InDim);
    Cost5=CostFunction(NN1,DataIn_rep(:,t),RuleNum,InDim);
    rep(t).Cost(1)=Cost1+Cost4+Cost5;
    rep(t).Error=[Cost1 Cost4 Cost5];
    Cost2=CostFunction(NN2,DataIn_rep(:,t),RuleNum,InDim);
    rep(t).Cost(2)=-Cost2;
    Cost3=CostFunction(NN3,DataIn_rep(:,t),RuleNum,InDim);
    rep(t).Cost(3)=-Cost3;
end

DataIn_pop=zeros(InDim,numel(pop));
for t=1:numel(pop)
    pop(t).Pos(1)=pop(t).Pos(1)-lamda*Delta(1);
    pop(t).Pos(2)=pop(t).Pos(2)-lamda*Delta(6);
    pop(t).Pos = max(pop(t).Pos, VarMin);
    pop(t).Pos = min(pop(t).Pos, VarMax);
end


end