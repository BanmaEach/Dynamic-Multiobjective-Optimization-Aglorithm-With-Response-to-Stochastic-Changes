function [IndWin,IndLos,IndMid,Roh]=Compete(pop1,pop2,pop3,index1,index2,index3,maxCost,minCost,Obj)
%�Ƚ�

fit1=pop1.Cost;

fit2=pop2.Cost;

fit3=pop3.Cost;

deltfit12=abs(sum(fit1-fit2));
deltfit13=abs(sum(fit1-fit3));
deltfit23=abs(sum(fit2-fit3));


Domflag12=Dominates(pop1,pop2);
Domflag21=Dominates(pop2,pop1);

Domflag13=Dominates(pop1,pop3);
Domflag31=Dominates(pop3,pop1);

Domflag23=Dominates(pop2,pop3);
Domflag32=Dominates(pop3,pop2);

FlagX=[Domflag12 Domflag13 Domflag21 Domflag23 Domflag31 Domflag32];
[~,Index_D]=find(FlagX==1);

Long=numel(Index_D);

switch Long
    case 1
        if FlagX(1)==1 || FlagX(6)==1
            IndLos=index2;
            if sum(fit1-fit3)<0
                IndWin=index1;
                IndMid=index3;
                Roh=(1/Obj)*sum(abs(fit1-fit2)./(maxCost-minCost));
            else
                IndWin=index3;
                IndMid=index1;
                Roh=(1/Obj)*sum(abs(fit3-fit2)./(maxCost-minCost));
            end
        end
        if FlagX(3)==1 || FlagX(5)==1
            IndLos=index1;
            if sum(fit2-fit3)<0
                IndWin=index2;
                IndMid=index3;
                Roh=(1/Obj)*sum(abs(fit2-fit1)./(maxCost-minCost));
            else
                IndWin=index3;
                IndMid=index2;
                Roh=(1/Obj)*sum(abs(fit3-fit1)./(maxCost-minCost));
            end
        end
        if FlagX(2)==1 || FlagX(4)==1
            IndLos=index3;
            if sum(fit1-fit2)<0
                IndWin=index1;
                IndMid=index2;
                Roh=(1/Obj)*sum(abs(fit1-fit3)./(maxCost-minCost));
            else
                IndWin=index2;
                IndMid=index1;
                Roh=(1/Obj)*sum(abs(fit2-fit3)./(maxCost-minCost));
            end
        end
    case 2
        % һ��֧������
        if FlagX(1)==1 && FlagX(2)==1  % 1֧�� 2��3
            IndWin=index1;
            if sum(fit2-fit3)<0
                IndMid=index2;
                IndLos=index3;
                Roh=(1/Obj)*sum(abs(fit1-fit3)./(maxCost-minCost));
            else
                IndMid=index3;
                IndLos=index2;
                Roh=(1/Obj)*sum(abs(fit1-fit2)./(maxCost-minCost));
            end
        end
        if FlagX(3)==1 && FlagX(4)==1  % 2֧�� 1��3
            IndWin=index2;
            if sum(fit1-fit3)<0
                IndMid=index1;
                IndLos=index3;
                Roh=(1/Obj)*sum(abs(fit2-fit3)./(maxCost-minCost));
            else
                IndMid=index3;
                IndLos=index1;
                Roh=(1/Obj)*sum(abs(fit2-fit1)./(maxCost-minCost));
            end
        end
        if FlagX(5)==1 && FlagX(6)==1  % 3֧�� 1��2
            IndWin=index3;
            if sum(fit1-fit2)<0
                IndMid=index1;
                IndLos=index2;
                Roh=(1/Obj)*sum(abs(fit3-fit2)./(maxCost-minCost));
            else
                IndMid=index2;
                IndLos=index1;
                Roh=(1/Obj)*sum(abs(fit3-fit1)./(maxCost-minCost));
            end
        end
        %����֧��һ��
        if FlagX(2)==1 && FlagX(4)==1
            IndLos=index3;
            if sum(fit1-fit2)<0
                IndWin=index1;
                IndMid=index2;
                Roh=(1/Obj)*sum(abs(fit1-fit3)./(maxCost-minCost));
            else
                IndWin=index2;
                IndMid=index1;
                Roh=(1/Obj)*sum(abs(fit2-fit3)./(maxCost-minCost));
            end
        end
        if FlagX(1)==1 && FlagX(6)==1
            IndLos=index2;
            if sum(fit1-fit3)<0
                IndWin=index1;
                IndMid=index3;
                Roh=(1/Obj)*sum(abs(fit2-fit3)./(maxCost-minCost));
            else
                IndWin=index3;
                IndMid=index1;
                Roh=(1/Obj)*sum(abs(fit1-fit2)./(maxCost-minCost));
            end
        end
        if FlagX(3)==1 && FlagX(5)==1
            IndLos=index1;
            if sum(fit2-fit3)<0
                IndWin=index2;
                IndMid=index3;
                Roh=(1/Obj)*sum(abs(fit2-fit1)./(maxCost-minCost));
            else
                IndWin=index3;
                IndMid=index2;
                Roh=(1/Obj)*sum(abs(fit3-fit1)./(maxCost-minCost));
            end
        end
    case 3
        if FlagX(3)==0 && FlagX(5)==0
            IndWin=index1;
            if sum(fit2-fit3)<0
                IndMid=index2;
                IndLos=index3;
                Roh=(1/Obj)*sum(abs(fit1-fit3)./(maxCost-minCost));
            else
                IndMid=index3;
                IndLos=index2;
                Roh=(1/Obj)*sum(abs(fit1-fit2)./(maxCost-minCost));
            end
        end
        if FlagX(1)==0 && FlagX(6)==0
            IndWin=index2;
            if sum(fit1-fit3)<0
                IndMid=index1;
                IndLos=index3;
                Roh=(1/Obj)*sum(abs(fit2-fit3)./(maxCost-minCost));
            else
                IndMid=index3;
                IndLos=index1;
                Roh=(1/Obj)*sum(abs(fit2-fit1)./(maxCost-minCost));
            end
        end
        if FlagX(2)==0 && FlagX(4)==0
            IndWin=index3;
            if sum(fit1-fit2)<0
                IndMid=index1;
                IndLos=index2;
                Roh=(1/Obj)*sum(abs(fit3-fit2)./(maxCost-minCost));
            else
                IndMid=index2;
                IndLos=index1;
                Roh=(1/Obj)*sum(abs(fit3-fit1)./(maxCost-minCost));
            end
        end
    case 0
        Roh=0;
        [~,index]=max([deltfit12 deltfit13 deltfit23]);
        if index==1
            if sum(fit1-fit2)<0
                IndWin=index1;
                IndLos=index2;
                IndMid=index3;
            else
                IndWin=index2;
                IndLos=index1;
                IndMid=index3;
            end
        end
        if index==2
            if sum(fit1-fit3)<0
                IndWin=index1;
                IndLos=index3;
                IndMid=index2;
            else
                IndWin=index3;
                IndLos=index1;
                IndMid=index2;
            end
        end
        if index==3
            if sum(fit2-fit3)<0
                IndWin=index2;
                IndLos=index3;
                IndMid=index1;
            else
                IndWin=index3;
                IndLos=index2;
                IndMid=index1;
            end
        end
end



%����Ӧ����
% if Flag==1
%     Roh=(1/Obj)*sum(abs(fit1-fit2)'./(maxCost-minCost));
% else
%     Roh=0;
% end

if isnan(Roh)
    Roh=0;
end

end