function AllDis = GetAllDis(rep)
%��AllDis
N = numel(rep);
for i=1:N
    repCost(i,:) = rep(i).Cost;
end

Dis = zeros(N, N);
Dist = zeros(N, N);
AllDis = zeros(N, 1);

for i = 1:N
    for j = 1:N
        if i == j
            Dis(i, j) = 0;
        else
            Dis(i, j) = sqrt(sum((repCost(i, :)-repCost(j, :)).^2));
        end
    end
    Dist(i, :) = sort(Dis(i, :), 2);
    sizeDist = size(Dist, 1);
    if sizeDist > 4
        AllDis(i, :) = sum(Dist(i, 1:4)) / 4;
    else
        AllDis(i, :) = sum(Dist(i, :)) / sizeDist;
    end
end

end