function [pop,rep]=InitDynamic(sizepop,nVar,VarMin,VarMax,DataIn1,DataIn23,DataIn4,NN1,NN2,NN3,NN4,InDim,RuleNum,DM,rep,pop)

if numel(rep)>DM
    Index=1:1:numel(rep);
    RandInd=randperm(numel(Index))';
    SelInd=RandInd(1:DM);
    for c=1:DM
        DecX(c,:)=rep(SelInd(c)).Pos;
    end
    [Pos,Cos,ACNN]=Dynamic_MOA_RL(DecX,DataIn1,DataIn23,DataIn4,NN1,NN2,NN3,NN4,InDim,RuleNum,DM);
    for a=1:DM
        pop(a).Pos=Pos(:,a)';
        pop(a).Cost=[Cos(1,a),Cos(2,a)+Cos(3,a),-Cos(4,a)];
        pop(a).Error=[Cos(1,a),Cos(2,a),Cos(3,a)];
    end

    [popx,rep]=Initial_MOA(sizepop-DM,nVar,VarMin,VarMax);
    RePop=popMap(ACNN,popx);
    pop=[pop(1:DM);RePop];
else
    DecX1=[];
    for k=1:numel(rep)
        DecX1(k,:)=rep(k).Pos;
    end

    CM=DM-numel(rep);

    DecX2=[];
    Index=1:1:numel(pop);
    RandInd=randperm(numel(Index))';
    SelInd=RandInd(1:CM);
    for c=1:CM
        DecX2(c,:)=pop(SelInd(c)).Pos;
    end
    DecX=[DecX1;DecX2];

    [Pos,Cos,ACNN]=Dynamic_MOA_RL(DecX,DataIn1,DataIn23,DataIn4,NN1,NN2,NN3,NN4,InDim,RuleNum,DM);
    for a=1:DM
        pop(a).Pos=Pos(:,a)';
        pop(a).Cost=[Cos(1,a),Cos(2,a)+Cos(3,a),-Cos(4,a)];
        pop(a).Error=[Cos(1,a),Cos(2,a),Cos(3,a)];
    end
    
    [popx,rep]=Initial_MOA(sizepop-DM,nVar,VarMin,VarMax);
    RePop=popMap(ACNN,popx);
    pop=[pop(1:DM);RePop];
end

end