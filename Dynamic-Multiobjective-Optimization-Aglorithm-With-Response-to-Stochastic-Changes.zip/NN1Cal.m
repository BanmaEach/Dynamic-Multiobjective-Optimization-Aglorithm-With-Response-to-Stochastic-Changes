function [NetOut_NOx,J_NOx]=NN1Cal(SamIn,Center_NOx,Width_NOx,a0_NOx,a_NOx,RuleNum,InDim)

for i=1:InDim
    for j=1:RuleNum
        MemFunUnitOut_NOx(i,j)=exp(-(SamIn(i)-Center_NOx(i,j))^2/Width_NOx(i,j)^2);% 闅跺睘灞傝緭鍑?
    end
end
% 瑙勫垯灞?
RuleUnitOut_NOx=prod(MemFunUnitOut_NOx); %瑙勫垯灞傝緭鍑?
% 褰掍竴鍖栧眰
RuleUnitOutSum_NOx=sum(RuleUnitOut_NOx); %瑙勫垯灞傝緭鍑烘眰鍜?
NormValue_NOx=RuleUnitOut_NOx./RuleUnitOutSum_NOx; %褰掍竴鍖栧眰杈撳嚭
% 杈撳嚭灞?
W_NOx=a0_NOx+a_NOx'*SamIn;%瑙勫垯鍚庝欢杈撳嚭
NetOut_NOx=NormValue_NOx*W_NOx; %鍗曚釜鏍锋湰杈撳嚭灞傝緭鍑猴紝鍗崇綉缁滃疄闄呰緭鍑?




for i=1:InDim
    for j=1:RuleNum
        J_NOx_b(i,j)=-2*((W_NOx(j)-NetOut_NOx)/RuleUnitOutSum_NOx)*RuleUnitOut_NOx(j)*(SamIn(i)-Center_NOx(i,j))/(Width_NOx(i,j)^2);
    end
end

J_NOx=-(NormValue_NOx*a_NOx')-sum(J_NOx_b,2)';
end