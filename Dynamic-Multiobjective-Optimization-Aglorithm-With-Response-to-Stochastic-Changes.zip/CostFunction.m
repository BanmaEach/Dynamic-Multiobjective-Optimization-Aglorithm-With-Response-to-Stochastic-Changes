function Cost=CostFunction(NN,DataIn,RuleNum,InDim)

a=NN.a;
a0=NN.a0;
Center=NN.Center;
Width=NN.Width;



SamIn=DataIn;
for i=1:InDim
    for j=1:RuleNum
        MemFunUnitOut(i,j)=exp(-(SamIn(i)-Center(i,j))^2/Width(i,j)^2);% 隶属层输出
    end
end
% 规则层
RuleUnitOut=prod(MemFunUnitOut); %规则层输出
% 归一化层
RuleUnitOutSum=sum(RuleUnitOut); %规则层输出求和
NormValue=RuleUnitOut./RuleUnitOutSum; %归一化层输出
% 输出层
W=a0+a'*SamIn;%规则后件输出
Cost=NormValue*W; %单个样本输出层输出，即网络实际输出

end