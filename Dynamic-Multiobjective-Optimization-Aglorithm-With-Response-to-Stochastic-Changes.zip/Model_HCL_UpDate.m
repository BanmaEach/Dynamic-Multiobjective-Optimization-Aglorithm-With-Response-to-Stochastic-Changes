function [Output_HCL,NN5,flag]=Model_HCL_UpDate(MaxIter,DataIn,DataOut_HCL,RuleNum,InDim,NN5,Delta,DataLong)

a=NN5.a;
a0=NN5.a0;
Center=NN5.Center;
Width=NN5.Width;
lamda=0.3;
La=[];
TrainNum=1;

for k=1:DataLong
    SamIn=DataIn(:,k);
    SamOut=DataOut_HCL(:,k);

    % 隶属�?
    for i=1:InDim
        for j=1:RuleNum
            MemFunUnitOut(i,j)=exp(-(SamIn(i)-Center(i,j))^2/Width(i,j)^2);% 隶属层输�?
        end
    end
    % 规则�?
    RuleUnitOut=prod(MemFunUnitOut); %规则层输�?
    % 归一化层
    RuleUnitOutSum=sum(RuleUnitOut); %规则层输出求�?
    NormValue=RuleUnitOut./RuleUnitOutSum; %归一化层输出
    % 输出�?
    W=a0+a'*SamIn;%规则后件输出
    NetOut=NormValue*W; %单个样本输出层输出，即网络实际输�?
    %         NetOut=NetOutT';
    Error(k)=SamOut-NetOut;%单个样本误差=期望输出-网络实际输出
end
APE=abs(Error)/abs(DataOut_HCL);

if APE<Delta*0.01
    flag=0;
else
    flag=1;

    for epoch=1:MaxIter %迭代
        NormValue=[];
        Amenda0=[];
        Amenda=[];
        AmendCenter=[];
        AmendWidth=[];
        MemFunUnitOut=[];
        WeightNum=3*InDim*RuleNum+RuleNum;
        jac=zeros(TrainNum,WeightNum);
        Q=zeros(WeightNum,WeightNum);
        g=zeros(1,WeightNum);

        for k=1:DataLong
            SamIn=DataIn(:,k);
            SamOut=DataOut_HCL(:,k);

            % 隶属�?
            for i=1:InDim
                for j=1:RuleNum
                    MemFunUnitOut(i,j)=exp(-(SamIn(i)-Center(i,j))^2/Width(i,j)^2);% 隶属层输�?
                end
            end
            % 规则�?
            RuleUnitOut=prod(MemFunUnitOut); %规则层输�?
            % 归一化层
            RuleUnitOutSum=sum(RuleUnitOut); %规则层输出求�?
            NormValue=RuleUnitOut./RuleUnitOutSum; %归一化层输出
            % 输出�?
            W=a0+a'*SamIn;%规则后件输出
            NetOut=NormValue*W; %单个样本输出层输出，即网络实际输�?
            %         NetOut=NetOutT';
            Error=SamOut-NetOut;%单个样本误差=期望输出-网络实际输出

            %% %%%%%%%%%%%%%%%%%改进的LM算法进行参数学习%%%%%%%%%%%%%%%%%
            %% 参数调整�?
            %权�?�修正量
            Amenda0=-NormValue;
            for i=1:InDim
                for j=1:RuleNum
                    Amenda(i,j)=-NormValue(j)*SamIn(i);
                end
            end
            %中心修正�?
            for i=1:InDim
                for j=1:RuleNum
                    AmendCenter(i,j)=-2*((W(j)-NetOut)/RuleUnitOutSum)*RuleUnitOut(j)*(SamIn(i)-Center(i,j))/(Width(i,j)^2);
                end
            end
            % 宽度修正�?
            for i=1:InDim
                for j=1:RuleNum
                    AmendWidth(i,j)=-2*((W(j)-NetOut)/RuleUnitOutSum)*RuleUnitOut(j)*(SamIn(i)-Center(i,j))^2/(Width(i,j)^3);
                end
            end
            %计算Jacobi
            AmendaReshape=reshape(Amenda',1,InDim*RuleNum);
            AmendCenterReshape=reshape(AmendCenter',1,InDim*RuleNum);
            AmendWidthReshape=reshape(AmendWidth',1,InDim*RuleNum);
            jac=horzcat(Amenda0,AmendaReshape,AmendCenterReshape,AmendWidthReshape);
            q=jac'*jac;
            yeta=jac*Error;
            Q=Q+q;   %Hessian 矩阵
            g=g+yeta;
        end
        AllError=SamOut-NetOut;%�?有样本误�?
        % Improve LM
        H_lm=Q+(lamda*eye(WeightNum,WeightNum));
        AmendAll=inv(H_lm)*g';
        Amenda0=AmendAll(1:RuleNum);
        Amenda1=AmendAll(RuleNum+1:RuleNum+InDim*RuleNum);
        Amenda=reshape(Amenda1,RuleNum,InDim);
        AmendCenter1=AmendAll(RuleNum+InDim*RuleNum+1:RuleNum+2*InDim*RuleNum);
        AmendCenter=reshape(AmendCenter1,RuleNum,InDim);
        AmendWidth1=AmendAll(RuleNum+2*InDim*RuleNum+1:end);
        AmendWidth=reshape(AmendWidth1,RuleNum,InDim);
        % 更新中心、宽度�?�权�?
        a0=a0-Amenda0;
        a=a-Amenda';
        Center=Center-AmendCenter';
        Width=Width-AmendWidth';
        % lamda=0.5*norm(AllError)+0.5*norm(g);
        % La=[La;lamda];
        % %计算RMSE
        %     TrainRMSE(epoch)=sqrt(sum((AllNetOut-TrainSamOut).^2)/TrainNum);
        %         %保存规则
        %     RuleNumHistory=[RuleNumHistory RuleNum];
    end
end

for k=1:DataLong
    SamIn=DataIn(:,k);
    SamOut=DataOut_HCL(:,k);
    for i=1:InDim
        for j=1:RuleNum
            MemFunUnitOut(i,j)=exp(-(SamIn(i)-Center(i,j))^2/Width(i,j)^2);% 隶属层输�?
        end
    end
    % 规则�?
    RuleUnitOut=prod(MemFunUnitOut); %规则层输�?
    % 归一化层
    RuleUnitOutSum=sum(RuleUnitOut); %规则层输出求�?
    NormValue=RuleUnitOut./RuleUnitOutSum; %归一化层输出
    % 输出�?
    W=a0+a'*SamIn;%规则后件输出
    Output_HCL(k)=NormValue*W; %单个样本输出层输出，即网络实际输�?
end

NN5.a=a;
NN5.a0=a0;
NN5.Center=Center;
NN5.Width=Width;
end