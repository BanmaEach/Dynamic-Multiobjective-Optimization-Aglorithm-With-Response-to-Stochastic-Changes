function index_Del=Constraint(rep,MaxminOut)
index_Del=[];
index=[];
for t=1:numel(rep)
    Cost(t,:)=rep(t).Cost;
    CostF(t,:)=rep(t).Error;
end

CostPG=-Cost(:,3)';
CostNOx=CostF(:,1)';
CostSO2=CostF(:,2)';
CostHCL=CostF(:,3)';

CostRes=[CostNOx;CostSO2;CostHCL;CostPG];

R_Opt=mapminmax('reverse',CostRes,MaxminOut);

R_Opt_NOx=R_Opt(1,:);
R_Opt_SO2=R_Opt(2,:);
R_Opt_HCL=R_Opt(3,:);
R_Opt_PG=R_Opt(4,:);


index1=find(R_Opt_PG>34);
index2=find(R_Opt_PG<25);
index3=find(R_Opt_NOx>230);
index4=find(R_Opt_NOx<30);
index5=find(R_Opt_SO2>2);
index6=find(R_Opt_SO2<0.1);
index7=find(R_Opt_HCL>9);
index8=find(R_Opt_HCL<0.5);

index=[index1 index2 index3 index4 index5 index6 index7 index8];

index_Del=unique(index);

end
