function NetOut=NNCal(DataIn,NN,RuleNum,InDim,DataLong)

Center=NN.Center;
Width=NN.Width;
a0=NN.a0;
a=NN.a;

for k=1:DataLong
    SamIn=DataIn(:,k);

    for i=1:InDim
        for j=1:RuleNum
            MemFunUnitOut(i,j)=exp(-(SamIn(i)-Center(i,j))^2/Width(i,j)^2);% 闅跺睘灞傝緭鍑?
        end
    end
    % 瑙勫垯灞?
    RuleUnitOut=prod(MemFunUnitOut); %瑙勫垯灞傝緭鍑?
    % 褰掍竴鍖栧眰
    RuleUnitOutSum=sum(RuleUnitOut); %瑙勫垯灞傝緭鍑烘眰鍜?
    NormValue=RuleUnitOut./RuleUnitOutSum; %褰掍竴鍖栧眰杈撳嚭
    % 杈撳嚭灞?
    W=a0+a'*SamIn;%瑙勫垯鍚庝欢杈撳嚭
    NetOut(k)=NormValue*W; %鍗曚釜鏍锋湰杈撳嚭灞傝緭鍑猴紝鍗崇綉缁滃疄闄呰緭鍑?
end
end