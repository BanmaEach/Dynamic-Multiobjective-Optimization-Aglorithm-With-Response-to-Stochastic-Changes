function [OPt_Result,OPt_DS_Res,flag,rep,pop,OptimizationTime,Metrics]=Optimization(NN1,NN2,NN3,NN4,DataIn1,DataIn23,DataIn4,Output,Iteration,rep,pop)

RuleNum=15;
InDim=6;
InDim1=6;
InDim2=6;
OutDim=1;

Obj=3;
sizepop=150;
nVar=3;
MOA_Maxiter=50;
nRep=50;
VarMin = [-1 -1 -0.1389]; % Lower Bound of Variables娑撳妾?
VarMax = [1 1 0.429]; % Upper Bound of Variables娑撳﹪妾?

OPt_Result=zeros(Obj,1);
OPt_DS_Res=zeros(nVar,1);

%% 
load MaxminIn
load MaxminOut

RealIn=mapminmax('reverse',[DataIn1(1:2,:); DataIn4(5,:)],MaxminIn);
RealOut=mapminmax('reverse',Output,MaxminOut);

R_NOx=RealOut(1);
R_SO2=RealOut(2);
R_HCL=RealOut(3);
R_Steam=RealOut(4);
%% 
tic;
DM=50;
if Iteration==1
    [pop,rep]=Initial_MOA(sizepop,nVar,VarMin,VarMax);
else
    [pop,rep]=InitDynamic(sizepop,nVar,VarMin,VarMax,DataIn1,DataIn23,DataIn4,NN1,NN2,NN3,NN4,InDim,RuleNum,DM,rep,pop);
end

%% 

[rep,pop]=Multi_Optimization(NN1,NN2,NN3,NN4,DataIn1,DataIn23,DataIn4,RuleNum,InDim1,InDim2,Obj,MaxminOut,pop,rep,sizepop,nVar,MOA_Maxiter,nRep,VarMin,VarMax);

%% 
        Cost=[];
        Position=[];

        if numel(rep)>0
            for t=1:numel(rep)
                Cost(t,:)=rep(t).Cost;
                Position(t,:)=rep(t).Pos;
                Cost_F(t,:)=rep(t).Error;
            end

            RefPoint=ones(1,4);
            FV=[Cost_F Cost(:,3)];
            HV = P_evaluate('HV',FV,RefPoint);
            SP= P_evaluate('SM',FV,RefPoint);
            Metrics=[HV SP];


            Cost(:,3)=-Cost(:,3);
            %Cost(:,3)=Cost(:,3);
            CostRes=[Cost(:,1)';Cost_F(:,2)';Cost_F(:,3)';Cost(:,3)'];

            R_Opt=mapminmax('reverse',CostRes,MaxminOut);

            R_Opt_NOx=R_Opt(1,:);
            R_Opt_SO2=R_Opt(2,:);
            R_Opt_HCL=R_Opt(3,:);
            R_Opt_Steam=R_Opt(4,:);

            DesR=[Position(:,1)';Position(:,2)';Position(:,3)'];
            R_DesR=mapminmax('reverse',DesR,MaxminIn);
            R_DesR_F=R_DesR(1,:);
            R_DesR_O=R_DesR(2,:);
            R_DesR_P=R_DesR(3,:);


            O1=(R_NOx-R_Opt_NOx)./R_NOx;
            O2=(R_Opt_Steam-R_Steam)./R_Steam;
            O4=(R_SO2-R_Opt_SO2)./R_SO2;
            O5=(R_HCL-R_Opt_HCL)./R_HCL;


            index33=find(R_DesR_P>84);
            O1(index33)=[];
            O2(index33)=[];
            O4(index33)=[];
            O5(index33)=[];
            R_Opt_NOx(index33)=[];
            R_Opt_Steam(index33)=[];
            R_Opt_SO2(index33)=[];
            R_Opt_HCL(index33)=[];
            R_DesR_F(index33)=[];
            R_DesR_O(index33)=[];
            R_DesR_P(index33)=[];
            %R_Opt(:,index33)=[];

            index33=find(R_DesR_P<74);
            O1(index33)=[];
            O2(index33)=[];
            O4(index33)=[];
            O5(index33)=[];
            R_Opt_NOx(index33)=[];
            R_Opt_Steam(index33)=[];
            R_Opt_SO2(index33)=[];
            R_Opt_HCL(index33)=[];
            R_DesR_F(index33)=[];
            R_DesR_O(index33)=[];
            R_DesR_P(index33)=[];
            %R_Opt(:,index33)=[];




            AAA=numel(O1);

            if AAA>0

                [OE,index]=max((O1)+O2+(O4)+(O5));

                if OE>=-100
                    OPt_Result=[R_Opt_NOx(index);R_Opt_SO2(index);R_Opt_HCL(index);R_Opt_Steam(index);];
                    OPt_DS_Res=[R_DesR_F(index);R_DesR_O(index);R_DesR_P(index)];
                    flag=1;
                else
                    OPt_Result=[R_NOx;R_SO2;R_HCL;R_Steam];
                    OPt_DS_Res=RealIn;
                    flag=0;
                end

            else
                OPt_Result=[R_NOx;R_SO2;R_HCL;R_Steam];
                OPt_DS_Res=RealIn;
                flag=0;
            end

        else
            OPt_Result=[R_NOx;R_SO2;R_HCL;R_Steam];
            OPt_DS_Res=RealIn;
            flag=0;
            Metrics=[0 0];
        end

        OptimizationTime=toc;

        disp(' ');
        fprintf('Dynamic Multi-Objective Optimization Time = %1s s .\n',num2str(OptimizationTime));
        if flag==1
            disp('Optimization')
        else
            disp('Un-optimization')
        end
end