function [AR, GD] = DominateDegree(rep)
%ARָ��
K = numel(rep);
for i=1:K
    repCost(i,:) = rep(i).Cost;
end
M = size(repCost, 2);
y = zeros(K, M);
C = zeros(K, M);
AR = zeros(K, 1);
for j = 1:M
    y(:, j) = sort(repCost(:, j));
end

for k = 1:K
    for t = 1:M
        C(k, t) = find(repCost(k, t) == y(:, t),1)/K;
    end
    AR(k) = sum(C(k, :))/M;
end


%GDָ��
G = zeros(K, K);

for d=1:M
    repMax(d)=max(repCost(:,d));
    repMin(d)=min(repCost(:,d));
end

for i = 1:K
    for e = 1:K
        if i == e
            G(i, e) = 0;
        else
            Gep = max(repCost(i, :)-repCost(e, :), 0)./(repMax-repMin);
            G(i, e) = sum(Gep)/M;
        end
    end
end
GD = sum(G, 2)/(K-1);
end
