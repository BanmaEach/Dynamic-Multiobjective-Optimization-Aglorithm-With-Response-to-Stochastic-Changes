function [C_NS, D_NS]=FindLeader(rep,pop)
N=numel(rep);
if 0<N && N<2
    C_NS=rep(1);
    D_NS=rep(1);
elseif N==0
    C_NS=pop(ceil(20*rand));
    D_NS=pop(ceil(20*rand));

elseif N>=2
    %��FR
    [AR, GD] = DominateDegree(rep);
    FR = AR + GD;
    
    %��AllDis
    AllDis = GetAllDis(rep);
    
    [~,index1]=min(FR);
    C_NS=rep(index1);
    [~,index2]=max(AllDis);
    D_NS=rep(index2);
end
end