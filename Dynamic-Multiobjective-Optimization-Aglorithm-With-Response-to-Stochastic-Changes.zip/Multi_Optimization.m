function [rep,pop]=Multi_Optimization(NN1,NN2,NN3,NN4,DataIn1,DataIn23,DataIn4,RuleNum,InDim1,InDim2,Obj,MaxminOut,pop,rep,sizepop,nVar,Maxiter,nRep,VarMin,VarMax)

%优化决策变量  输入1-炉膛温度，输�?6-烟气氧含�?


%%  基本设置

Phi=1*ones(Maxiter,1);
Phi0=1;
elderAp=0;
Ap=zeros(Maxiter,1);
DeltaAp=zeros(Maxiter,1);
%%
for k=1:sizepop
    DataIn1(1:2,:)=pop(k).Pos(1:2)';
    DataIn23(1:2,:)=pop(k).Pos(1:2)';
    DataIn4(1:2,:)=pop(k).Pos(1:2)';
    DataIn4(5,:)=pop(k).Pos(3)';

    Cost1=CostFunction(NN1,DataIn1,RuleNum,InDim1);
    Cost4=CostFunction(NN2,DataIn23,RuleNum,InDim2);
    Cost5=CostFunction(NN3,DataIn23,RuleNum,InDim2);
    pop(k).Cost(1)=Cost1;
    pop(k).Error=[Cost1 Cost4 Cost5];
    %Cost2=CostFunction(NN2,DataIn,RuleNum,InDim);
    pop(k).Cost(2)=Cost4+Cost5;
    Cost3=CostFunction(NN4,DataIn4,RuleNum,InDim2);
    pop(k).Cost(3)=-Cost3;
end
pop=DetermineDomination(pop);
rep = [rep;pop(~[pop.IsDominated])];
%% 主循�?-种群寻优
popCost=zeros(sizepop,Obj);
ClassNum=3;
for t=1:Maxiter   %寻优迭代
    for n=1:sizepop
        popCost(n,:)=pop(n).Cost;
    end
    minCost=min(popCost);
    maxCost=max(popCost);
    %将粒子分为一�?
    Ind=1:1:sizepop;
    NewInd=randperm(numel(Ind))';
    Index1=NewInd(1:sizepop/ClassNum);
    Index2=NewInd(sizepop/ClassNum+1:2*(sizepop/ClassNum));
    Index3=NewInd(2*(sizepop/ClassNum)+1:3*(sizepop/ClassNum));

    IndWin=zeros((sizepop/ClassNum),1);
    IndLos=zeros((sizepop/ClassNum),1);
    IndMid=zeros((sizepop/ClassNum),1);
    Roh=zeros((sizepop/ClassNum),1);



    for i=1:(sizepop/ClassNum)
        %����
        [IndWin(i,:),IndLos(i,:),IndMid(i,:),Roh(i,:)]=Compete(pop(Index1(i)),pop(Index2(i)),pop(Index3(i)),Index1(i),Index2(i),Index3(i),maxCost,minCost,Obj);
    end

    elderAp=Ap(t);
    Ap(t)=0.8*elderAp+0.2*(sum(Roh)/(sizepop/ClassNum));
    DeltaAp(t)=Ap(t)-elderAp;
    Phi(t)=Phi0+0.8*DeltaAp(t);

    [C_NS,D_NS]=FindLeader(rep,pop);

    if DeltaAp(t)>0
        leader=C_NS;
    else
        leader=D_NS;
    end

    for i=1:(sizepop/ClassNum)
        %���¡��ӡ�����
        r0=rand(1,nVar);
        r1=rand(1,nVar);
        Vellast=pop(IndLos(i,:)).Vel;
        pop(IndLos(i,:)).Vel=r0.*pop(IndLos(i,:)).Vel + r1.*(pop(IndWin(i,:)).Pos-pop(IndLos(i,:)).Pos);
        pop(IndLos(i,:)).Pos=pop(IndLos(i,:)).Pos+pop(IndLos(i,:)).Vel+r0.*(pop(IndLos(i,:)).Vel-Vellast);
        %��ΧԼ��
        pop(IndLos(i,:)).Pos = max(pop(IndLos(i,:)).Pos, VarMin);
        pop(IndLos(i,:)).Pos = min(pop(IndLos(i,:)).Pos, VarMax);

        %���¡��м䡱����
        pop(IndMid(i,:)).Vel=rand(1,nVar).*pop(IndMid(i,:)).Vel + rand(1,nVar).*(pop(IndWin(i,:)).Pos-pop(IndMid(i,:)).Pos) + Phi(t)*rand(1,nVar).*(leader.Pos-pop(IndMid(i,:)).Pos);
        pop(IndMid(i,:)).Pos=pop(IndMid(i,:)).Pos+pop(IndMid(i,:)).Vel;
        %��ΧԼ��
        pop(IndMid(i,:)).Pos = max(pop(IndMid(i,:)).Pos, VarMin);
        pop(IndMid(i,:)).Pos = min(pop(IndMid(i,:)).Pos, VarMax);

        %���¡��š�����
        beta = 1.5;
        sigma_u = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
        sigma_v = 1;
        u = normrnd(0,sigma_u);
        v = normrnd(0,sigma_v);
        s = u/(abs(v))^(1/beta);

        pop(IndWin(i,:),:).Vel=0.5*rand(1,nVar).*s.*pop(IndWin(i,:)).Vel;
        pop(IndWin(i,:),:).Pos=pop(IndWin(i,:)).Pos+pop(IndWin(i,:)).Vel;
        %��ΧԼ��
        pop(IndWin(i,:)).Pos = max(pop(IndWin(i,:)).Pos, VarMin);
        pop(IndWin(i,:)).Pos = min(pop(IndWin(i,:)).Pos, VarMax);
    end



    for j=1:sizepop

        DataIn1(1:2,:)=pop(k).Pos(1:2)';
        DataIn23(1:2,:)=pop(k).Pos(1:2)';
        DataIn4(1:2,:)=pop(k).Pos(1:2)';
        DataIn4(5,:)=pop(k).Pos(3)';

        pop(j).Vellast2=pop(j).Vellast1;
        pop(j).Vellast1=pop(j).Vel;
        Cost1=CostFunction(NN1,DataIn1,RuleNum,InDim1);
        Cost4=CostFunction(NN2,DataIn23,RuleNum,InDim2);
        Cost5=CostFunction(NN3,DataIn23,RuleNum,InDim2);
        pop(j).Cost(1)=Cost1;
        pop(j).Error=[Cost1 Cost4 Cost5];
        %Cost2=CostFunction(NN2,DataIn,RuleNum,InDim);
        pop(j).Cost(2)=Cost4+Cost5;
        Cost3=CostFunction(NN4,DataIn4,RuleNum,InDim2);
        pop(j).Cost(3)=-Cost3;
    end

    pop=DetermineDomination(pop);
    rep = [rep;pop(~[pop.IsDominated])];
    rep=DetermineDomination(rep);
    rep = rep(~[rep.IsDominated]);

    index_Del=Constraint(rep,MaxminOut);
    rep(index_Del) = [];


    if numel(rep) > nRep % �?查rep库是否满
        Extra = numel(rep) - nRep;
        for e = 1:Extra
            rep = DeleteOneRepMemebr_3(rep); %删除rep库中的一个解
        end
    end
end

end