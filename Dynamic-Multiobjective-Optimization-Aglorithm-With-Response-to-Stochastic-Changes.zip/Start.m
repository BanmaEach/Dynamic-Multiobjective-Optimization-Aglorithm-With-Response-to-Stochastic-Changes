function [OptResults,OptDecsions]=Start(input,output)
%% \
RuleNum=15;
InDim=6;
OutDim=1;

%% \

TrainInput=input;
Train1=output(1,:);
Train2=output(2,:);
Train3=output(3,:);
Train4=output(4,:);
Train5=output(5,:);

DataStNum=1;

DataLong=1;

DataSt_In=TrainInput;
DataSt_Out_NOx=Train1;
DataSt_Out_Steam=Train2;
DataSt_Out_CE=Train3;
DataSt_Out_SO2=Train4;
DataSt_Out_HCL=Train5;


load SamTrains
load SamTests1
load SamTests2
load SamTests3
load SamTests4
load SamTests5

DataSt_Inx=mapminmax('apply',DataSt_In,SamTrains);
DataSt_Out_NOx_x=mapminmax('apply',DataSt_Out_NOx,SamTests1);
DataSt_Out_Steam_x=mapminmax('apply',DataSt_Out_Steam,SamTests2);
DataSt_Out_CE_x=mapminmax('apply',DataSt_Out_CE,SamTests3);
DataSt_Out_SO2_x=mapminmax('apply',DataSt_Out_SO2,SamTests4);
DataSt_Out_HCL_x=mapminmax('apply',DataSt_Out_HCL,SamTests5);

%%
load NN1.mat
load NN2.mat
load NN3.mat
load NN4.mat
load NN5.mat

index=[];
MaxIter=50;
Delta=0.2;
%ModelUpdateTime=zeros(1,DataStNum/DataLong);
ModelUpdateTime1=zeros(1,DataStNum/DataLong);
ModelUpdateTime2=zeros(1,DataStNum/DataLong);
ModelUpdateTime3=zeros(1,DataStNum/DataLong);
ModelUpdateTime4=zeros(1,DataStNum/DataLong);
ModelUpdateTime5=zeros(1,DataStNum/DataLong);
OptimizationTime=zeros(1,DataStNum/DataLong);

%%
Obj=3;
sizepop=150;
nVar=2;
MOA_Maxiter=50;
nRep=50;
VarMin = [-1 -1]; % Lower Bound of Variables涓嬮�?
VarMax = [1 1]; % Upper Bound of Variables涓婇�?

OPt_Result=zeros(DataStNum/DataLong,DataLong,4);
OPt_DS_Res=zeros(DataStNum/DataLong,DataLong,nVar);
%%
Flag_NOx=zeros(DataStNum/DataLong,1);
Flag_Steam=zeros(DataStNum/DataLong,1);
%Flag_CE=zeros(DataStNum/DataLong,1);
Flag_SO2=zeros(DataStNum/DataLong,1);
Flag_HCL=zeros(DataStNum/DataLong,1);
flag=zeros(DataStNum/DataLong,1);
for i=1:(DataStNum/DataLong)
    disp(' ');
    disp(['-------------------------------Dynamic Multi-Objective Optimization Times : ', num2str(i),'-------------------------------']);

    DataIn=DataSt_Inx(:,(i-1)*DataLong+1:i*DataLong);

    DataOut_NOx=DataSt_Out_NOx_x(:,(i-1)*DataLong+1:i*DataLong);
    DataOut_Steam=DataSt_Out_Steam_x(:,(i-1)*DataLong+1:i*DataLong);
    DataOut_CE=DataSt_Out_CE_x(:,(i-1)*DataLong+1:i*DataLong);
    DataOut_SO2=DataSt_Out_SO2_x(:,(i-1)*DataLong+1:i*DataLong);
    DataOut_HCL=DataSt_Out_HCL_x(:,(i-1)*DataLong+1:i*DataLong);
    %% \
    disp(' ');
    disp('Model Updating');
    tic;
    [OP_NOx((i-1)*DataLong+1:i*DataLong),NN1,Flag_NOx(i,:)]=Model_NOx_UpDate(MaxIter,DataIn,DataOut_NOx,RuleNum,InDim,NN1,Delta,DataLong);
    ModelUpdateTime1(i)=toc;
    tic;
    [OP_Steam((i-1)*DataLong+1:i*DataLong),NN2,Flag_Steam(i,:)]=Model_Steam_UpDate(MaxIter,DataIn,DataOut_Steam,RuleNum,InDim,NN2,Delta,DataLong);
    ModelUpdateTime2(i)=toc;
    % tic;
    % [OP_CE((i-1)*DataLong+1:i*DataLong),NN3,Flag_CE(i,:)]=Model_CE_UpDate(MaxIter,DataIn,DataOut_CE,RuleNum,InDim,NN3,Delta,DataLong);
    % ModelUpdateTime3(i)=toc;
    tic;
    [OP_SO2((i-1)*DataLong+1:i*DataLong),NN4,Flag_SO2(i,:)]=Model_SO2_UpDate(MaxIter,DataIn,DataOut_SO2,RuleNum,InDim,NN4,Delta,DataLong);
    ModelUpdateTime4(i)=toc;
    tic;
    [OP_HCL((i-1)*DataLong+1:i*DataLong),NN5,Flag_HCL(i,:)]=Model_HCL_UpDate(MaxIter,DataIn,DataOut_HCL,RuleNum,InDim,NN5,Delta,DataLong);
    ModelUpdateTime5(i)=toc;
    %ModelUpdateTime(i)=toc0;
    disp(' ');
    disp(['Model Update Time = ', num2str(ModelUpdateTime1(i)+ModelUpdateTime2(i)+ModelUpdateTime3(i)+ModelUpdateTime4(i)+ModelUpdateTime5(i)),' s']);

    %%
    R_NOx=mapminmax('reverse',OP_NOx((i-1)*DataLong+1:i*DataLong),SamTests1);
    R_Steam=mapminmax('reverse',OP_Steam((i-1)*DataLong+1:i*DataLong),SamTests2);
    %R_CE=mapminmax('reverse',OP_CE((i-1)*DataLong+1:i*DataLong),SamTests3);
    R_SO2=mapminmax('reverse',OP_SO2((i-1)*DataLong+1:i*DataLong),SamTests4);
    R_HCL=mapminmax('reverse',OP_HCL((i-1)*DataLong+1:i*DataLong),SamTests5);
    R_Input=mapminmax('reverse', DataIn,SamTrains);
    RealIn=[R_Input(1,:);R_Input(6,:)];
    %%
    disp('--------------------------------------------------------');
    disp('Optimization Begin');

    for j=1:DataLong
        tic;
        Input=DataIn(:,j);

        if i==1 && j==1
            pop=Initial_MOA(sizepop,nVar,VarMin,VarMax);
            rep=[];
        end
        if i>1 && j==1
            [rep,~]=Dynamic_MOA(rep,pop,NN1,NN2,NN3,NN4,NN5,Input,DataSt_Inx(:,(i-1)*DataLong),InDim,RuleNum,OP_NOx((i-1)*DataLong:(i-1)*DataLong+1),OP_Steam((i-1)*DataLong:(i-1)*DataLong+1),OP_CE((i-1)*DataLong:(i-1)*DataLong+1),OP_SO2((i-1)*DataLong:(i-1)*DataLong+1),OP_HCL((i-1)*DataLong:(i-1)*DataLong+1),VarMin,VarMax);
            pop=Initial_MOA(sizepop,nVar,VarMin,VarMax);
        end

        [rep,pop]=Multi_Optimization(NN1,NN2,NN3,NN4,NN5,Input,RuleNum,InDim,Obj,R_NOx(j),R_Steam(j),R_SO2(j),R_HCL(j),SamTests1,SamTests2,SamTests3,SamTests4,SamTests5,pop,rep,sizepop,nVar,MOA_Maxiter,nRep,VarMin,VarMax);

%% 
        Cost=[];
        Position=[];
        Cost_F=[];

        if numel(rep)>0
            for t=1:numel(rep)
                Cost(t,:)=rep(t).Cost;
                Position(t,:)=rep(t).Pos;
                Cost_F(t,:)=rep(t).Error;
            end
            %Cost(:,2)=-Cost(:,2);
            Cost(:,3)=-Cost(:,3);
            R_Opt_NOx=mapminmax('reverse',Cost(:,1)',SamTests1);
            R_Opt_Steam=mapminmax('reverse',Cost(:,3)',SamTests2);
            %R_Opt_CE=mapminmax('reverse',Cost(:,3)',SamTests3);
            R_Opt_SO2=mapminmax('reverse',Cost_F(:,2)',SamTests4);
            R_Opt_HCL=mapminmax('reverse',Cost_F(:,3)',SamTests5);

            DesG=repmat(Input(2:5),1,numel(rep));
            DesR=[Position(:,1)';DesG;Position(:,2)'];
            R_DesR=mapminmax('reverse',DesR,SamTrains);
            R_DesR_F=R_DesR(1,:);
            R_DesR_O=R_DesR(6,:);


            O1=(R_NOx(j)-R_Opt_NOx)./R_NOx(j);
            O2=(R_Opt_Steam-R_Steam(j))./R_Steam(j);
            %O3=(R_Opt_CE-R_CE(j))./R_CE(j);
            O4=(R_SO2(j)-R_Opt_SO2)./R_SO2(j);
            O5=(R_HCL(j)-R_Opt_HCL)./R_HCL(j);

            
            index1=find(O4<-0.2);
            O1(index1)=[];
            O2(index1)=[];
            %O3(index1)=[];
            O4(index1)=[];
            O5(index1)=[];
            R_Opt_NOx(index1)=[];
            R_Opt_Steam(index1)=[];
            %R_Opt_CE(index1)=[];
            R_Opt_SO2(index1)=[];
            R_Opt_HCL(index1)=[];

            index11=find(O4>1);
            O1(index11)=[];
            O2(index11)=[];
            %O3(index11)=[];
            O4(index11)=[];
            O5(index11)=[];
            R_Opt_NOx(index11)=[];
            R_Opt_Steam(index11)=[];
            %R_Opt_CE(index11)=[];
            R_Opt_SO2(index11)=[];
            R_Opt_HCL(index11)=[];

            index2=find(O5<-0.2);
            O1(index2)=[];
            O2(index2)=[];
            %O3(index2)=[];
            O4(index2)=[];
            O5(index2)=[];
            R_Opt_NOx(index2)=[];
            R_Opt_Steam(index2)=[];
            %R_Opt_CE(index2)=[];
            R_Opt_SO2(index2)=[];
            R_Opt_HCL(index2)=[];
            
            index22=find(O5>1);
            O1(index22)=[];
            O2(index22)=[];
            %O3(index22)=[];
            O4(index22)=[];
            O5(index22)=[];
            R_Opt_NOx(index22)=[];
            R_Opt_Steam(index22)=[];
            %R_Opt_CE(index22)=[];
            R_Opt_SO2(index22)=[];
            R_Opt_HCL(index22)=[];
            
            index3=find(O1<-0.2);
            O1(index3)=[];
            O2(index3)=[];
            %O3(index3)=[];
            O4(index3)=[];
            O5(index3)=[];
            R_Opt_NOx(index3)=[];
            R_Opt_Steam(index3)=[];
            %R_Opt_CE(index3)=[];
            R_Opt_SO2(index3)=[];
            R_Opt_HCL(index3)=[];

            index33=find(R_Opt_NOx<20);
            O1(index33)=[];
            O2(index33)=[];
            %O3(index33)=[];
            O4(index33)=[];
            O5(index33)=[];
            R_Opt_NOx(index33)=[];
            R_Opt_Steam(index33)=[];
            %R_Opt_CE(index33)=[];
            R_Opt_SO2(index33)=[];
            R_Opt_HCL(index33)=[];


            if numel(O1)>0
                Oo1=mapminmax(O1);
                Oo2=mapminmax(O2);
                Oo4=mapminmax(O4);
                Oo5=mapminmax(O5);

                [OE,index]=max((Oo1)+(Oo2)+(Oo4)+(Oo5));

                if OE>=0
                    OPt_Result(i,j,:)=[R_Opt_NOx(index);R_Opt_Steam(index);R_Opt_SO2(index);R_Opt_HCL(index)];
                    OPt_DS_Res(i,j,:)=[R_DesR_F(index);R_DesR_O(index)];
                    flag(i)=1;
                else
                    OPt_Result(i,j,:)=[R_NOx(j);R_Steam(j);R_SO2(j);R_HCL(j)];
                    OPt_DS_Res(i,j,:)=[RealIn(1,j);RealIn(2,j)];
                    flag(i)=0;
                end

            else
                OPt_Result(i,j,:)=[R_NOx(j);R_Steam(j);R_SO2(j);R_HCL(j)];
                OPt_DS_Res(i,j,:)=[RealIn(1,j);RealIn(2,j)];
                flag(i)=0;
            end

        else
            OPt_Result(i,j,:)=[R_NOx(j);R_Steam(j);R_SO2(j);R_HCL(j)];
            OPt_DS_Res(i,j,:)=[RealIn(1,j);RealIn(2,j)];
            flag(i)=0;
        end

        OptimizationTime(i)=toc;
        disp(' ');
        fprintf('Dynamic Multi-Objective Optimization Time = %1s s,  Number of non-dominated solution %2s .\n',num2str(OptimizationTime(i)),num2str(numel(rep)));
    end

end

for l=1:(DataStNum/DataLong)
    OPt_R(1,(l-1)*DataLong+1:l*DataLong)=OPt_Result(l,:,1);
    OPt_R(2,(l-1)*DataLong+1:l*DataLong)=OPt_Result(l,:,2);
    OPt_R(3,(l-1)*DataLong+1:l*DataLong)=OPt_Result(l,:,3);
    OPt_R(4,(l-1)*DataLong+1:l*DataLong)=OPt_Result(l,:,4);
    %OPt_R(5,(l-1)*DataLong+1:l*DataLong)=OPt_Result(l,:,5);
end

for g=1:(DataStNum/DataLong)
    OPt_Decision(1,(g-1)*DataLong+1:g*DataLong)=OPt_DS_Res(g,:,1);
    OPt_Decision(2,(g-1)*DataLong+1:g*DataLong)=OPt_DS_Res(g,:,2);
end


R_NOx=mapminmax('reverse',OP_NOx,SamTests1);
R_Steam=mapminmax('reverse',OP_Steam,SamTests2);
%R_CE=mapminmax('reverse',OP_CE,SamTests3);
R_SO2=mapminmax('reverse',OP_SO2,SamTests4);
R_HCL=mapminmax('reverse',OP_HCL,SamTests5);

%%
OptResults=OPt_R;
XiugaiNOx=OPt_R(1,:);
XiugaiST=OPt_R(2,:);
%XiugaiCE=OPt_R(3,:);
XiugaiSO2=OPt_R(3,:);
XiugaiHCL=OPt_R(4,:);

XRNOx=R_NOx;
XRST=R_Steam;
%XRCE=R_CE;
XRSO2=R_SO2;
XRHCL=R_HCL;

%% 优化结果输出

OPrate_NOx=(XiugaiNOx-XRNOx)./XRNOx;


OPrate_ST=(XiugaiST-XRST)./XRST;


%OPrate_CE=(XiugaiCE.*100-XRCE.*100)./(XRCE.*100);


OPrate_SO2=(XiugaiSO2-XRSO2)./(XRSO2);


OPrate_HCL=(XiugaiHCL-XRHCL)./(XRHCL);

%% 决策变量
OptDecsions=OPt_Decision;


%%
xv=find(flag==0);

OPrateNOx=mean(OPrate_NOx)
OPrateST=mean(OPrate_ST)
%OPrateCE=mean(OPrate_CE)
OPrateSO2=mean(OPrate_SO2)
OPrateHCL=mean(OPrate_HCL)

end