function [Pos,Cos,ACNN]=Dynamic_MOA_RL(DecX,DataIn1,DataIn23,DataIn4,NN1,NN2,NN3,NN4,InDim,RuleNum,DM)

%%
obj=4;
a_NOx=NN1.a;
a0_NOx=NN1.a0;
Center_NOx=NN1.Center;
Width_NOx=NN1.Width;

a_SO2=NN2.a;
a0_SO2=NN2.a0;
Center_SO2=NN2.Center;
Width_SO2=NN2.Width;

a_HCL=NN3.a;
a0_HCL=NN3.a0;
Center_HCL=NN3.Center;
Width_HCL=NN3.Width;

a_PG=NN4.a;
a0_PG=NN4.a0;
Center_PG=NN4.Center;
Width_PG=NN4.Width;
%%

samples=DM;


StIn1=DataIn1(3:6);
StIn23=DataIn23(3:6);
StIn4_1=DataIn4(3:4);
StIn4_2=DataIn4(6);

TAU=20;
for t=1:samples
    SamIn=DecX(t,:)';
    for tau=1:TAU
        if tau==1
            SamIn_P1=[SamIn(1:2);StIn1];
            SamIn_P23=[SamIn(1:2);StIn23];
            SamIn_P4=[SamIn(1:2);StIn4_1;SamIn(3);StIn4_2];
        else
            SamIn_P1=[SamIn_Lf_P(1:2,tau-1);StIn1];
            SamIn_P23=[SamIn_Lf_P(1:2,tau-1);StIn23];
            SamIn_P4=[SamIn_Lf_P(1:2,tau-1);StIn4_1;SamIn_Lf_P(3,tau-1);StIn4_2];
            %SamIn_P=SamIn_Lf_P(:,tau-1);
        end
        %SamIn_ReAj_P(:,tau)=SamIn_P;

        [NetOut_NOx_P(tau),J_NOx_P]=NN1Cal(SamIn_P1,Center_NOx,Width_NOx,a0_NOx,a_NOx,RuleNum,InDim);

        [NetOut_SO2_P(tau),J_SO2_P]=NN1Cal(SamIn_P23,Center_SO2,Width_SO2,a0_SO2,a_SO2,RuleNum,InDim);

        [NetOut_HCl_P(tau),J_HCl_P]=NN1Cal(SamIn_P23,Center_HCL,Width_HCL,a0_HCL,a_HCL,RuleNum,InDim);

        [NetOut_PG_P(tau),J_ST_P]=NN1Cal(SamIn_P4,Center_PG,Width_PG,a0_PG,a_PG,RuleNum,InDim);



        F(:,t)=[NetOut_NOx_P(1);NetOut_SO2_P(1);NetOut_HCl_P(1);NetOut_PG_P(1)];


        J=[-J_NOx_P; -J_SO2_P; -J_HCl_P; J_ST_P];

        Nj=[norm(J_NOx_P); norm(J_SO2_P); norm(J_HCl_P); norm(J_ST_P)];

        Jmin=min(Nj);

        J=[(Jmin/Nj(1))*(-J_NOx_P); (Jmin/Nj(2))*(-J_SO2_P); (Jmin/Nj(3))*(-J_HCl_P); (Jmin/Nj(4))*(J_ST_P)];

        Phi=zeros(1,obj);

        Jb=J(1,:);
        for i=2:obj
            Phi(i)=sum(Jb.*J(i,:))/(norm(Jb)*norm(J(i,:)));
            if Phi(i)<0
                Jnew1=J(i,:)-((sum(J(i,:).*Jb)/(norm(J(i,:))^2))*Jb);
                Jnew2=Jb-((sum(Jb.*J(i,:))/(norm(Jb)^2))*J(i,:));
                Jb=Jnew1+Jnew2;
            else
                Jb=Jb+J(i,:);
            end
        end

        SamIn_Lf_P(:,tau)=SamIn-0.02*Jb(1:3)';
        %SamIn_Lf_P(:,tau)=SamIn_P-0.02*(J(1,:)+J(2,:)+J(3,:)+J(4,:)+J(5,:))';
        %SamIn_Lf_P(:,tau)=SamIn_P-0.05*(0.3*(J_NOx_P-J_ST_P-J_CE_P))';
        %SamIn_Lf_P(:,tau)=SamIn_P+0.05*(J_NOx_P)';
        %SumJ(:,tau)=[norm(J(1,:));norm(J(2,:));norm(J(3,:));norm(J(4,:));norm(J(5,:))];
    end
   %NPX(:,t)=[SamIn_Lf_P(1,tau);StIn;SamIn_Lf_P(6,tau)];
   NPX(:,t)=SamIn_Lf_P(:,tau);
end

DecX_Fac=NPX;
%% 
nVar=3;
VarMin=-1*ones(1,nVar)';
VarMax=1*ones(1,nVar)';

for t=1:DM
    DecX_Fac(:,t)=max(DecX_Fac(:,t), VarMin);

    Cost1(t)=CostFunction(NN1,[DecX_Fac(1:2,t);StIn1],RuleNum,InDim);
    Cost4(t)=CostFunction(NN4,[DecX_Fac(1:2,t);StIn23],RuleNum,InDim);
    Cost2(t)=CostFunction(NN2,[DecX_Fac(1:2,t);StIn23],RuleNum,InDim);
    Cost3(t)=CostFunction(NN3,[DecX_Fac(1:2,t);StIn4_1;DecX_Fac(3,t);StIn4_2],RuleNum,InDim);
end
Pos=DecX_Fac;
Cos=[Cost1;Cost2;Cost3;Cost4];

%%

in_dim = nVar;  % 输入层
hidden_unit_num = 15;  % 隐含层
out_dim = nVar;  % 输出层

lr=0.01;
Iter=100000;
E0=0.001;

W1 = 0.1*rand(hidden_unit_num, in_dim);      % 初始化输入层与隐含层之间的权值
B1 = 0.1*rand(hidden_unit_num, 1);           % 初始化输入层与隐含层之间的阈值
W2 = 0.1*rand(out_dim, hidden_unit_num);     % 初始化输出层与隐含层之间的权值
B2 = 0.1*rand(out_dim, 1);                   % 初始化输出层与隐含层之间的阈值

W1Ex=[W1  B1];
W2Ex=[W2  B2];

%%
for z=1:DM
    R_SamIn(:,z)=DecX(z,:)';
end

SamInEx=[R_SamIn' ones(DM,1)]';
Ac_SamOut=Pos;

for t=1:Iter
    HiddenOut = tansig(W1Ex*SamInEx);   % 隐含层网络输出
    HiddenOutEx=[HiddenOut' ones(DM,1)]';
    NetworkOut = W2Ex*HiddenOutEx;      % 输出层网络输出
    NetworkOut=real(NetworkOut);
    Error=Ac_SamOut-NetworkOut;

    SSE = sumsqr(Error);               % 能量函数（误差平方和）
    ErrHistory(t) = SSE;               % 记录每次学习的误差

    if SSE < E0                        % 如果达到误差阈值就退出
        break;
    end

    Delta2 = Error;
    Delta1 = W2' * Delta2 .* (1 - HiddenOut.^2);

    dW2Ex = Delta2 * HiddenOutEx';
    dW1Ex = Delta1 * SamInEx';
    W2Ex = W2Ex + lr*dW2Ex;
    W1Ex = W1Ex + lr*dW1Ex;
end

%%

HiddenOut = tansig(W1Ex*SamInEx);   % 隐含层网络输出
HiddenOutEx=[HiddenOut' ones(DM,1)]';
NextX = W2Ex*HiddenOutEx;      % 输出层网络输出
Error=Ac_SamOut-NextX;

ACNN.W1Ex=W1Ex;
ACNN.W2Ex=W2Ex;

end