function RePop=popMap(ACNN,popx)


W1Ex=ACNN.W1Ex;
W2Ex=ACNN.W2Ex;


%StIn=Input(2:5)';

for i=1:numel(popx)
    Posx(:,i)=popx(i).Pos;
end

SamInEx=[Posx; ones(1,numel(popx))];


HiddenOut = tansig(W1Ex*SamInEx);   % 隐含层网络输出
HiddenOutEx=[HiddenOut' ones(numel(popx),1)]';
NetworkOut = W2Ex*HiddenOutEx;      % 输出层网络输出

nVar=3;
VarMin=-1*ones(1,nVar)';
VarMax=1*ones(1,nVar)';
for j=1:numel(popx)
    NetworkOut(:,j)=max(NetworkOut(:,j), VarMin);
    NetworkOut(:,j)=min(NetworkOut(:,j), VarMax);
end

RePop=popx;

for i=1:numel(popx)
    RePop(i).Pos=NetworkOut(:,i)';
end


end