function [pop,rep]=Initial_MOA(sizepop,nVar,VarMin,VarMax)

empty_particle.Pos = [];
empty_particle.Vel = [];
empty_particle.Cost = [];
empty_particle.Error = [];
empty_particle.IsDominated = [];
empty_particle.Vellast1 = [];
empty_particle.Vellast2 = [];
pop = repmat(empty_particle, sizepop, 1);
%%
VarSize=[1 nVar];

for i=1:sizepop
    pop(i).Pos=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Vel=0.2*rand(1,nVar);
    pop(i).Vellast1=zeros(1,nVar);
    pop(i).Vellast2=zeros(1,nVar);
end
rep=[];
end