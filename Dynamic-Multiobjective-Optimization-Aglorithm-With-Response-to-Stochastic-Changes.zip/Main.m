clc;clear
close all;
%% \
load Input.mat
load Output.mat

N=100;
M=9;
O=1;
InDim=6;
His_MSF=[];

RealValue=zeros(4,N*(M+O));
OptResults=zeros(4,N*(M+O));
ModelResults=zeros(4,N*(M+O));
OPT_Res=zeros(4,N*(M+O));

M_Input_NN1=zeros(InDim,M);
M_Input_NN23=zeros(InDim,M);
M_Input_NN4=zeros(InDim,M);
M_Output=zeros(4,M);

MO_Input_NN1=zeros(InDim,M);
MO_Input_NN23=zeros(InDim,M);
MO_Input_NN4=zeros(InDim,M);

SharedInput=Input(:,1:4);

SCRInput=Input(:,5:6);

DeacidInput=Input(:,7:8);

HeatInput=Input(:,9:10);

Input_NN1_R=[SharedInput SCRInput]';

Input_NN23_R=[SharedInput DeacidInput]';

Input_NN4_R=[SharedInput HeatInput]';
Output=Output';
Output_R=Output;

OptInput=[SharedInput(:,1:2) HeatInput(:,1)]';
[~,MaxminIn]=mapminmax(OptInput);


[Input_NN1,MaxminIn1]=mapminmax(Input_NN1_R);
[Input_NN23,MaxminIn23]=mapminmax(Input_NN23_R);
[Input_NN4,MaxminIn4]=mapminmax(Input_NN4_R);
[Output_RR,MaxminOut]=mapminmax(Output_R);

save MaxminOut MaxminOut
save MaxminIn MaxminIn


RuleNum=15;
load NN1.mat
load NN2.mat
load NN3.mat
load NN4.mat


for i=1:N
    disp(' ');
    disp(['------------------------------------------Optimization: ', num2str(i),'------------------------------------------']);
    %% Optimization
    O_Input_NN1=Input_NN1(:,(i-1)*(M+O)+1);
    O_Input_NN23=Input_NN23(:,(i-1)*(M+O)+1);
    O_Input_NN4=Input_NN4(:,(i-1)*(M+O)+1);
    O_Output=Output_RR(:,(i-1)*(M+O)+1);

    OptResults(:,(i-1)*(M+O)+2:i*(M+O))=NaN*ones(4,M);

    if i==1
        pop=[];
        rep=[];
    end

    [OptResults(:,(i-1)*(M+O)+1),OptDecsions(:,i),flag(i),rep,pop,OptimizationTime(i),Metrics(i,:)]=Optimization(NN1,NN2,NN3,NN4,O_Input_NN1,O_Input_NN23,O_Input_NN4,O_Output,i,rep,pop);

    RealValue(:,(i-1)*(M+O)+2:i*(M+O))=NaN*ones(4,M);
    RealOutput=mapminmax('reverse',O_Output,MaxminOut);
    RealValue(:,(i-1)*(M+O)+1)=RealOutput;

    MHV=sum(Metrics(:,1))/sum(flag);
    MSP=sum(Metrics(:,2))/sum(flag);
    %% Model Updating
    for j=1:M
        M_Input_NN1(:,j)=Input_NN1(:,(i-1)*(M+O)+j+1);
        M_Input_NN23(:,j)=Input_NN23(:,(i-1)*(M+O)+j+1);
        M_Input_NN4(:,j)=Input_NN4(:,(i-1)*(M+O)+j+1);
        M_Output(:,j)=Output_RR(:,(i-1)*(M+O)+j+1);
    end

    OptDec=mapminmax('apply',OptDecsions(:,i),MaxminIn);
    for k=1:M
        MO_Input_NN1(:,k)=[OptDec(1:2);M_Input_NN1(3:end,k)];
        MO_Input_NN23(:,k)=[OptDec(1:2);M_Input_NN23(3:end,k)];
        MO_Input_NN4(:,k)=[OptDec(1:2);M_Input_NN4(3:4,k);OptDec(3);M_Input_NN4(6,k)];
    end

    OptNOx=NNCal(MO_Input_NN1,NN1,RuleNum,InDim,M);
    OptSO2=NNCal(MO_Input_NN23,NN2,RuleNum,InDim,M);
    OptHCl=NNCal(MO_Input_NN23,NN3,RuleNum,InDim,M);
    OptPG=NNCal(MO_Input_NN4,NN4,RuleNum,InDim,M);
    Opt_R=[OptNOx;OptSO2;OptHCl;OptPG];

    OPT=mapminmax('reverse',Opt_R,MaxminOut);
    OPT_Res(:,(i-1)*(M+O)+2:i*(M+O))=OPT;
    OPT_Res(:,(i-1)*(M+O)+1)=NaN*ones(4,O);

    [NN1,NN2,NN3,NN4,ModelResults(:,(i-1)*(M+O)+2:i*(M+O)),Flag(:,i)]=ModelUpdate(M_Input_NN1,M_Input_NN23,M_Input_NN4,M_Output,MaxminOut,NN1,NN2,NN3,NN4,M);
    ModelResults(:,(i-1)*(M+O)+1)=NaN*ones(4,O);
    %%

    Results(:,(i-1)*(M+O)+1:i*(M+O))=[OptResults(:,i),ModelResults(:,(i-1)*(M+O)+2:i*(M+O))];

end
index_of_nansx = isnan(ModelResults(1,:));
ModelResults(:,index_of_nansx)=[];
Output(:,index_of_nansx)=[];
RMSE=sqrt(sum((ModelResults(1,:)-Output(1,1:900)).^2)/900);
MAPE=mean(abs(ModelResults(1,:)-Output(1,1:900))./Output(1,1:900))*100




index_of_nans = isnan(OptResults(1,:));

Q_OptResults=OptResults;
Q_RealValue=RealValue;
Q_OptResults(:,index_of_nans)=[];
Q_RealValue(:,index_of_nans)=[];

OptRate=(Q_OptResults-Q_RealValue)./Q_RealValue;

AveOptRate=mean(OptRate,2)

%%

figure
subplot(4,1,1)
plot(Output(1,1:N*(M+O)),'k-')
hold on
plot(ModelResults(1,:),'b--.','MarkerSize',8)
plot(RealValue(1,:),'g*','MarkerSize',4)
plot(OptResults(1,:),'ro','MarkerSize',4)
%plot(OPT_Res(1,:),'m-')
legend('Data','Model Output','Real Value','Optimization Results','FontSize',8,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('NOx Emission')
set(gca,'FontName','Times New Roman','FontSize',10)

subplot(4,1,2)
plot(Output(2,1:N*(M+O)),'k-')
hold on
plot(ModelResults(2,:),'b--.','MarkerSize',8)
plot(RealValue(2,:),'g*','MarkerSize',4)
plot(OptResults(2,:),'ro','MarkerSize',4)
%plot(OPT_Res(2,:),'m-')
legend('Data','Model Output','Real Value','Optimization Results','FontSize',8,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('SO_2 Emission')
set(gca,'FontName','Times New Roman','FontSize',10)

subplot(4,1,3)
plot(Output(3,1:N*(M+O)),'k-')
hold on
plot(ModelResults(3,:),'b--.','MarkerSize',8)
plot(RealValue(3,:),'g*','MarkerSize',4)
plot(OptResults(3,:),'ro','MarkerSize',4)
%plot(OPT_Res(3,:),'m-')
legend('Data','Model Output','Real Value','Optimization Results','FontSize',8,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('HCl Emission')
set(gca,'FontName','Times New Roman','FontSize',10)

subplot(4,1,4)
plot(Output(4,1:N*(M+O)),'k-')
hold on
plot(ModelResults(4,:),'b--.','MarkerSize',8)
plot(RealValue(4,:),'g*','MarkerSize',4)
plot(OptResults(4,:),'ro','MarkerSize',4)
%plot(OPT_Res(4,:),'m-')
legend('Data','Model Output','Real Value','Optimization Results','FontSize',8,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('Power Generation')
set(gca,'FontName','Times New Roman','FontSize',10)

set(gcf,'unit','centimeters','position',[2 2 36 22])


for i=1:100
    RealInput(:,i)=[Input_NN4_R(1:2,(i-1)*(M+O)+1); Input_NN4_R(5,(i-1)*(M+O)+1)];
end


figure
subplot(3,1,1)
plot(RealInput(1,:),'k-')
hold on
plot(OptDecsions(1,:),'--o','MarkerFaceColor',[1 0 0],'Color',[1 0 0],'MarkerSize',3,'LineWidth',1)
legend('Real value','Optimization Results','FontSize',12,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('Furnace Temperature (℃)')
set(gca,'FontName','Times New Roman','FontSize',14)
subplot(3,1,2)
plot(RealInput(2,:),'k-')
hold on
plot(OptDecsions(2,:),'--o','MarkerFaceColor',[0 0 1],'Color',[0 0 1],'MarkerSize',3,'LineWidth',1)
legend('Real value','Optimization Results','FontSize',12,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('Flue Gas Oxygen Content (%)')
set(gca,'FontName','Times New Roman','FontSize',14)
subplot(3,1,3)
plot(RealInput(3,:),'k-')
hold on
plot(OptDecsions(3,:),'--o','MarkerFaceColor',[0,0.690,0.314],'Color',[0,0.690,0.314],'MarkerSize',3,'LineWidth',1)
legend('Real value','Optimization Results','FontSize',12,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('Main Steam Flow (t/h)')
set(gca,'FontName','Times New Roman','FontSize',14)
set(gcf,'unit','centimeters','position',[6 6 32 20])


Real_MSF=[mean(RealInput(3,:)),std(RealInput(3,:))]
Opt_MSF=[mean(OptDecsions(3,:)),std(OptDecsions(3,:))]



figure
plot(flag)

sum(flag)

%% 


AAAAA=Output(:,1:N*(M+O))-ModelResults;
% CCC=sqrt(AAAAA.^2);
% 
% DDD=abs(AAAAA)./Output(:,1:N*(M+O));
% 
% 
% for i=1:100
% 
%     BBBB(:,i)=sum(DDD(:,(i-1)*10+2:i*10),2);
% end
% 
% sum(BBBB,2)/900



for i=1:100
X(i)=(i-1)*(M+O)+1;
end
Ya=30*ones(1,100);
Yb=50*ones(1,100);

figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(Output(1,1:N*(M+O)),'k-')
hold on
plot(ModelResults(1,:),'-o','MarkerFaceColor',[0.858,0.192,0.141],'Color',[0.858,0.192,0.141],'MarkerSize',3)
for i=1:100
line([X(i),X(i)],[Ya(i),Yb(i)],'color',[0.851 0.326 0.098],'LineStyle','-')
hold on
end
legend('Real Value','Model Output','Optimization Sampling','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('NOx Emission (mg/m^3)')
axis([0 1000 30 300]);
set(gca,'FontName','Times New Roman','FontSize',16)
subplot('position', [0.13,0.13,0.775,0.24])
plot(AAAAA(1,:),'k-')
axis([0 1000 -30 40]);
xlabel('Data Sample')
ylabel('Error (mg/m^3)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])





for i=1:100
X(i)=(i-1)*(M+O)+1;

end
Ya=0*ones(1,100);
Yb=0.2*ones(1,100);

figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(Output(2,1:N*(M+O)),'k-')
hold on
plot(ModelResults(2,:),'-o','MarkerFaceColor',[0.8,0,0.612],'Color',[0.8,0,0.612],'MarkerSize',3)
for i=1:100
line([X(i),X(i)],[Ya(i),Yb(i)],'color',[0.851 0.326 0.098],'LineStyle','-')
hold on
end
legend('Real Value','Model Output','Optimization Sampling','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('SO_2 Emission (mg/m^3)')
axis([0 1000 0 2.5]);
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 10])
subplot('position', [0.13,0.13,0.775,0.24])
plot(AAAAA(2,:),'k-')
axis([0 1000 -0.5 0.6]);
xlabel('Data Sample')
ylabel('Error (mg/m^3)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])




for i=1:100
X(i)=(i-1)*(M+O)+1;

end
Ya=0*ones(1,100);
Yb=1*ones(1,100);

figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(Output(3,1:N*(M+O)),'k-')
hold on
plot(ModelResults(3,:),'-o','MarkerFaceColor',[0,0.439,0.753],'Color',[0,0.439,0.753],'MarkerSize',3)
for i=1:100
line([X(i),X(i)],[Ya(i),Yb(i)],'color',[0.851 0.326 0.098],'LineStyle','-')
hold on
end
legend('Real Value','Model Output','Optimization Sampling','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('HCl Emission (mg/m^3)')
axis([0 1000 0 16]);
set(gca,'FontName','Times New Roman','FontSize',16)
subplot('position', [0.13,0.13,0.775,0.24])
plot(AAAAA(3,:),'k-')
axis([0 1000 -2 2]);
xlabel('Data Sample')
ylabel('Error (mg/m^3)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])


for i=1:100
X(i)=(i-1)*(M+O)+1;

end
Ya=18*ones(1,100);
Yb=19*ones(1,100);

figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(Output(4,1:N*(M+O)),'k-')
hold on
plot(ModelResults(4,:),'-o','MarkerFaceColor',[0,0.690,0.314],'Color',[0,0.690,0.314],'MarkerSize',3)
for i=1:100
line([X(i),X(i)],[Ya(i),Yb(i)],'color',[0.851 0.326 0.098],'LineStyle','-')
hold on
end
legend('Real Value','Model Output','Optimization Sampling','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('Power Generation (MW)')
axis([0 1000 18 34]);
set(gca,'FontName','Times New Roman','FontSize',16)
subplot('position', [0.13,0.13,0.775,0.24])
plot(AAAAA(4,:),'k-')
axis([0 1000 -0.6 0.7]);
xlabel('Data Sample')
ylabel('Error (mg/m^3)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])

%% 
Index=isnan(RealValue(1,:));
RealValue1=RealValue(1,~Index);
OptResults1=OptResults(1,~Index);

IR1=((OptResults1-RealValue1)./RealValue1)*100;
figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(RealValue1,'k-')
hold on
plot(OptResults1,'-o','MarkerFaceColor',[0.858,0.192,0.141],'Color',[0.858,0.192,0.141],'MarkerSize',3)
%plot(OPT_Res(4,:),'m-')
legend('Real Value','Optimization Result','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('NOx Emission (mg/m^3)')
%axis([0 100 20 35]);
set(gca,'FontName','Times New Roman','FontSize',16)
subplot('position', [0.13,0.13,0.775,0.24])
plot(IR1,'r--')
xlabel('Data Sample')
ylabel('Improvement Rate (%)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])



RealValue2=RealValue(2,~Index);
OptResults2=OptResults(2,~Index);

IR2=((OptResults2-RealValue2)./RealValue2)*100;
figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(RealValue2,'k-','MarkerSize',4)
hold on
plot(OptResults2,'-o','MarkerFaceColor',[0.8,0,0.612],'Color',[0.8,0,0.612],'MarkerSize',3)
%plot(OPT_Res(4,:),'m-')
legend('Real Value','Optimization Result','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('SO_2 Emission (mg/m^3)')
%axis([0 100 20 35]);
set(gca,'FontName','Times New Roman','FontSize',16)
subplot('position',[0.13,0.13,0.775,0.24])
plot(IR2,'r--')
xlabel('Data Sample')
ylabel('Improvement Rate (%)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])


RealValue3=RealValue(3,~Index);
OptResults3=OptResults(3,~Index);

IR3=((OptResults3-RealValue3)./RealValue3)*100;

figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(RealValue3,'k-','MarkerSize',4)
hold on
plot(OptResults3,'-o','MarkerFaceColor',[0,0.439,0.753],'Color',[0,0.439,0.753],'MarkerSize',3)
%plot(OPT_Res(4,:),'m-')
legend('Real Value','Optimization Result','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('HCl Emission (mg/m^3)')
%axis([0 100 20 35]);
set(gca,'FontName','Times New Roman','FontSize',16)
subplot('position',[0.13,0.13,0.775,0.24])
plot(IR3,'r--')
xlabel('Data Sample')
ylabel('Improvement Rate (%)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])




RealValue4=RealValue(4,~Index);
OptResults4=OptResults(4,~Index);

IR4=((OptResults4-RealValue4)./RealValue4)*100;


figure
subplot('position', [0.13,0.53,0.775,0.4])
plot(RealValue4,'k-','MarkerSize',4)
hold on
plot(OptResults4,'-o','MarkerFaceColor',[0,0.690,0.314],'Color',[0,0.690,0.314],'MarkerSize',3)
%plot(OPT_Res(4,:),'m-')
legend('Real Value','Optimization Result','FontSize',14,'FontName','Times New Roman','NumColumns',4)
xlabel('Data Sample')
ylabel('Power Generation (MW)')
set(gca,'FontName','Times New Roman','FontSize',16)
subplot('position',[0.13,0.13,0.775,0.24])
plot(IR4,'r--')
xlabel('Data Sample')
ylabel('Improvement Rate (%)')
set(gca,'FontName','Times New Roman','FontSize',16)
set(gcf,'unit','centimeters','position',[6 6 32 13])


% save RealValue1 RealValue1
% save RealValue2 RealValue2
% save RealValue3 RealValue3
% save RealValue4 RealValue4
% 
% save OptResults1 OptResults1
% save OptResults2 OptResults2
% save OptResults3 OptResults3
% save OptResults4 OptResults4