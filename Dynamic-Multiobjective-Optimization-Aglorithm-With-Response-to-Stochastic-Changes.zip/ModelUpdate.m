function [NN1,NN2,NN3,NN4,ModelResults,Flag]=ModelUpdate(DataIn1,DataIn23,DataIn4,DataOut,MaxminOut,NN1,NN2,NN3,NN4,DataLong)

%% \
RuleNum=15;
InDim1=6;
InDim2=6;
OutDim=1;

%%
% load NN1.mat
% load NN2.mat
% load NN3.mat
% load NN4.mat

index=[];
MaxIter=200;
Delta=0.5;

%% \

tic;
[ModelOut_NOx_R,NN1,Flag_NOx]=Model_NOx_UpDate(MaxIter,DataIn1,DataOut(1,:),RuleNum,InDim1,NN1,Delta,DataLong);
ModelUpdateTime1=toc;

tic;
[ModelOut_SO2_R,NN2,Flag_SO2]=Model_SO2_UpDate(MaxIter,DataIn23,DataOut(2,:),RuleNum,InDim2,NN2,Delta,DataLong);
ModelUpdateTime2=toc;

tic;
[ModelOut_HCL_R,NN3,Flag_HCL]=Model_HCL_UpDate(MaxIter,DataIn23,DataOut(3,:),RuleNum,InDim2,NN3,Delta,DataLong);
ModelUpdateTime3=toc;

tic;
[ModelOut_PGE_R,NN4,Flag_MSF]=Model_Steam_UpDate(MaxIter,DataIn4,DataOut(4,:),RuleNum,InDim2,NN4,Delta,DataLong);
ModelUpdateTime4=toc;

%% 
ModelOut_R=[ModelOut_NOx_R;ModelOut_SO2_R;ModelOut_HCL_R;ModelOut_PGE_R];

ModelOut=mapminmax('reverse',ModelOut_R,MaxminOut);

ModelResults=ModelOut;
Flag=[Flag_NOx;Flag_MSF;Flag_SO2;Flag_HCL];
%% 

disp(' ');
disp(['Model Update Time = ', num2str(ModelUpdateTime1+ModelUpdateTime2+ModelUpdateTime3+ModelUpdateTime4),' s']);
end